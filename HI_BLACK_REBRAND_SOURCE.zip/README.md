# HÍ BLACK — Rebrand project

Giữ ý tưởng/cấu trúc giao diện của app hiện tại và đổi nhận diện thành HÍ BLACK.
Đây là mã nguồn Android dựng lại từ đầu theo cấu trúc đã kiểm tra, không phải APK gốc đã được ký lại.
