package com.hiblack.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    final int WHITE=Color.rgb(245,245,245), MUTED=Color.rgb(154,154,154), PANEL=Color.rgb(17,17,17);

    TextView title(String s,float size){
        TextView t=new TextView(this); t.setText(s); t.setTextColor(WHITE); t.setTextSize(size);
        t.setGravity(Gravity.CENTER); t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        t.setPadding(8,12,8,12); return t;
    }
    Button btn(String s){
        Button b=new Button(this); b.setText(s); b.setTextColor(WHITE); b.setAllCaps(false);
        b.setBackgroundColor(PANEL); return b;
    }
    @Override public void onCreate(Bundle b){super.onCreate(b); show();}
    void show(){
        ScrollView sv=new ScrollView(this);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20,24,20,24); root.setBackgroundColor(Color.BLACK);
        sv.addView(root); setContentView(sv);

        root.addView(title("HÍ BLACK",30));
        TextView sub=title("SYSTEM READY",13); sub.setTextColor(MUTED); root.addView(sub);

        String[] cards={"AIM / RETICLE","GAME SETTINGS","OVERLAY","PERFORMANCE","DNS / TOOLS","VISUAL","NETWORK","SECURITY","CONTROL","ADVANCED","PROFILE","SETTINGS"};
        for(String s:cards){
            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
            TextView lab=new TextView(this); lab.setText(s); lab.setTextColor(WHITE); lab.setTextSize(15);
            lab.setPadding(14,8,8,8); row.addView(lab,new LinearLayout.LayoutParams(0,58,1));
            Switch sw=new Switch(this); sw.setText("OFF"); sw.setTextColor(MUTED);
            sw.setOnCheckedChangeListener((v,c)->v.setText(c?"ON":"OFF")); row.addView(sw);
            row.setBackgroundColor(PANEL);
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,60); rp.setMargins(0,4,0,4);
            root.addView(row,rp);
        }
        Button game=btn("MỞ GAME"); root.addView(game,new LinearLayout.LayoutParams(-1,56));
        game.setOnClickListener(v->Toast.makeText(this,"HÍ BLACK • Demo",Toast.LENGTH_SHORT).show());
    }
}
