# HÍ BLACK V2 — Build APK bằng GitHub Actions

Không cần Terminal để build APK.

1. Upload toàn bộ nội dung project này lên repository.
2. Mở tab **Actions**.
3. Chọn **Build HÍ BLACK APK**.
4. Bấm **Run workflow**.
5. Khi workflow hoàn tất, mở run đó và tải artifact **HI-BLACK-APK**.

APK tạo ra là bản debug để thử nghiệm.
