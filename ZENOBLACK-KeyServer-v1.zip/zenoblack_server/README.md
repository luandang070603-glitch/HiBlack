# ZENOBLACK Key Server

Server quản lý license key cho IPA ZENOBLACK.

## Chức năng
- `/api/activate`: xác thực key lần đầu và bind key với HWID; ghi IP request.
- `/api/validate`: kiểm tra lại key/HWID mỗi lần mở app; key bị khóa/reset sẽ có hiệu lực.
- `/api/admin/keys`: tạo/list key (header `x-admin-token`).
- `/api/admin/keys/reset`: reset HWID + IP để key có thể bind máy khác.
- `/api/admin/keys/lock`: khóa/mở khóa key.
- `/api/admin/keys/delete`: xóa key.

## Chạy
```bash
npm install
cp .env.example .env
# sửa ADMIN_TOKEN
npm start
```

Server mặc định chạy ở `http://localhost:3000`.

## API tạo key
```bash
curl -X POST http://localhost:3000/api/admin/keys \
  -H 'content-type: application/json' \
  -H 'x-admin-token: YOUR_TOKEN' \
  -d '{"days":30}'
```

## API reset key
```bash
curl -X POST http://localhost:3000/api/admin/keys/reset \
  -H 'content-type: application/json' \
  -H 'x-admin-token: YOUR_TOKEN' \
  -d '{"key":"ZENO-XXXX-XXXX-XXXX"}'
```

## Lưu ý triển khai
Để IPA trên iPhone gọi được server, server phải có HTTPS và một URL public. Sau khi có URL, đặt URL đó vào `API_BASE_URL` trong `public/app.js` của IPA rồi đóng gói/ký lại IPA.
