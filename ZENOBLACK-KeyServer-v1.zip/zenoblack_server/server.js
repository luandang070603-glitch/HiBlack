import express from 'express';
import cors from 'cors';
import crypto from 'crypto';
import Database from 'better-sqlite3';

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || 'CHANGE_ME';
const CORS_ORIGIN = process.env.CORS_ORIGIN || '*';

app.set('trust proxy', 1);
app.use(cors({ origin: CORS_ORIGIN === '*' ? true : CORS_ORIGIN }));
app.use(express.json({ limit: '32kb' }));

const db = new Database(process.env.DB_PATH || './zenoblack.db');
db.pragma('journal_mode = WAL');
db.exec(`CREATE TABLE IF NOT EXISTS keys (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  key TEXT UNIQUE NOT NULL,
  expires_at INTEGER NOT NULL,
  locked INTEGER NOT NULL DEFAULT 0,
  hwid TEXT,
  bound_ip TEXT,
  device_name TEXT,
  os_version TEXT,
  created_at INTEGER NOT NULL,
  last_seen_at INTEGER
)`);

const now = () => Date.now();
const clean = v => typeof v === 'string' ? v.trim().slice(0, 200) : '';
const getIp = req => (req.ip || req.socket.remoteAddress || '').replace(/^::ffff:/, '');
const makeKey = () => 'ZENO-' + crypto.randomBytes(8).toString('hex').toUpperCase().match(/.{1,4}/g).join('-');
const admin = (req,res,next) => {
  if (req.get('x-admin-token') !== ADMIN_TOKEN) return res.status(401).json({ok:false,error:'Unauthorized'});
  next();
};

function keyView(row){
  if(!row) return null;
  return {key:row.key, expiresAt:row.expires_at, locked:!!row.locked, hwid:row.hwid, ip:row.bound_ip, deviceName:row.device_name, osVersion:row.os_version, createdAt:row.created_at, lastSeenAt:row.last_seen_at};
}

app.get('/api/health', (req,res)=>res.json({ok:true,service:'ZENOBLACK key server',time:now()}));

app.post('/api/activate', (req,res)=>{
  const key = clean(req.body?.key).toUpperCase();
  const hwid = clean(req.body?.hwid);
  const deviceName = clean(req.body?.deviceName);
  const osVersion = clean(req.body?.osVersion);
  if(!key || !hwid) return res.status(400).json({ok:false,error:'Missing key or HWID'});
  const row = db.prepare('SELECT * FROM keys WHERE key=?').get(key);
  if(!row) return res.status(404).json({ok:false,error:'KEY_NOT_FOUND'});
  if(row.locked) return res.status(403).json({ok:false,error:'KEY_LOCKED'});
  if(row.expires_at <= now()) return res.status(403).json({ok:false,error:'KEY_EXPIRED'});
  if(row.hwid && row.hwid !== hwid) return res.status(403).json({ok:false,error:'HWID_MISMATCH'});

  const ip = getIp(req);
  db.prepare(`UPDATE keys SET hwid=COALESCE(hwid,?), bound_ip=?, device_name=?, os_version=?, last_seen_at=? WHERE key=?`)
    .run(hwid, ip, deviceName, osVersion, now(), key);
  const updated = db.prepare('SELECT * FROM keys WHERE key=?').get(key);
  res.json({ok:true,key:updated.key,hwid:updated.hwid,ip:updated.bound_ip,expiresAt:updated.expires_at,remainingSeconds:Math.max(0,Math.floor((updated.expires_at-now())/1000)),deviceName:updated.device_name,osVersion:updated.os_version});
});

app.post('/api/validate', (req,res)=>{
  const key = clean(req.body?.key).toUpperCase();
  const hwid = clean(req.body?.hwid);
  if(!key || !hwid) return res.status(400).json({ok:false,error:'Missing key or HWID'});
  const row = db.prepare('SELECT * FROM keys WHERE key=?').get(key);
  if(!row) return res.status(404).json({ok:false,error:'KEY_NOT_FOUND'});
  if(row.locked) return res.status(403).json({ok:false,error:'KEY_LOCKED'});
  if(row.expires_at <= now()) return res.status(403).json({ok:false,error:'KEY_EXPIRED'});
  if(row.hwid && row.hwid !== hwid) return res.status(403).json({ok:false,error:'HWID_MISMATCH'});
  const ip=getIp(req);
  db.prepare('UPDATE keys SET bound_ip=?,last_seen_at=? WHERE key=?').run(ip,now(),key);
  res.json({ok:true,key:row.key,hwid:row.hwid,ip,expiresAt:row.expires_at,remainingSeconds:Math.max(0,Math.floor((row.expires_at-now())/1000)),locked:false});
});

app.post('/api/admin/keys', admin, (req,res)=>{
  const days = Math.max(1, Math.min(3650, Number(req.body?.days || 30)));
  const key = clean(req.body?.key).toUpperCase() || makeKey();
  const expiresAt = now() + days*86400000;
  try {
    db.prepare('INSERT INTO keys(key,expires_at,created_at) VALUES(?,?,?)').run(key,expiresAt,now());
    res.json({ok:true,key,expiresAt});
  } catch(e){ res.status(409).json({ok:false,error:'KEY_EXISTS'}); }
});

app.get('/api/admin/keys', admin, (req,res)=>{
  const rows=db.prepare('SELECT * FROM keys ORDER BY id DESC').all();
  res.json({ok:true,keys:rows.map(keyView)});
});

app.post('/api/admin/keys/reset', admin, (req,res)=>{
  const key=clean(req.body?.key).toUpperCase();
  if(!key) return res.status(400).json({ok:false,error:'Missing key'});
  const r=db.prepare('UPDATE keys SET hwid=NULL,bound_ip=NULL,device_name=NULL,os_version=NULL,last_seen_at=NULL WHERE key=?').run(key);
  res.json({ok:r.changes>0});
});

app.post('/api/admin/keys/lock', admin, (req,res)=>{
  const key=clean(req.body?.key).toUpperCase();
  const locked=!!req.body?.locked;
  if(!key) return res.status(400).json({ok:false,error:'Missing key'});
  const r=db.prepare('UPDATE keys SET locked=? WHERE key=?').run(locked?1:0,key);
  res.json({ok:r.changes>0,locked});
});

app.post('/api/admin/keys/delete', admin, (req,res)=>{
  const key=clean(req.body?.key).toUpperCase();
  const r=db.prepare('DELETE FROM keys WHERE key=?').run(key);
  res.json({ok:r.changes>0});
});

app.listen(PORT,()=>console.log(`ZENOBLACK key server listening on :${PORT}`));
